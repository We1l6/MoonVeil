var searchData=
[
  ['fireball_61',['FireBall',['../classFireBall.html',1,'']]],
  ['fireballmonster_62',['FireBallMonster',['../classFireBallMonster.html',1,'']]],
  ['firestorm_63',['FireStorm',['../classFireStorm.html',1,'']]],
  ['floralwretch_64',['FloralWretch',['../classFloralWretch.html',1,'']]],
  ['frameatributes_65',['FrameAtributes',['../structFrameAtributes.html',1,'']]]
];
