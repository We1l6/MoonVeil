var searchData=
[
  ['fireball_59',['FireBall',['../classFireBall.html',1,'']]],
  ['fireballmonster_60',['FireBallMonster',['../classFireBallMonster.html',1,'']]],
  ['firestorm_61',['FireStorm',['../classFireStorm.html',1,'']]],
  ['floralwretch_62',['FloralWretch',['../classFloralWretch.html',1,'']]],
  ['frameatributes_63',['FrameAtributes',['../structFrameAtributes.html',1,'']]]
];
