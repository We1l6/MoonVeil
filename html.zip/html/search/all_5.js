var searchData=
[
  ['fireball_14',['FireBall',['../classFireBall.html',1,'']]],
  ['fireballmonster_15',['FireBallMonster',['../classFireBallMonster.html',1,'']]],
  ['firestorm_16',['FireStorm',['../classFireStorm.html',1,'']]],
  ['floralwretch_17',['FloralWretch',['../classFloralWretch.html',1,'']]],
  ['frameatributes_18',['FrameAtributes',['../structFrameAtributes.html',1,'']]]
];
