var searchData=
[
  ['loggermanager_28',['LoggerManager',['../classLoggerManager.html',1,'']]],
  ['loggerwindow_29',['LoggerWindow',['../classLoggerWindow.html',1,'']]]
];
