var searchData=
[
  ['loggermanager_29',['LoggerManager',['../classLoggerManager.html',1,'']]],
  ['loggerwindow_30',['LoggerWindow',['../classLoggerWindow.html',1,'']]]
];
