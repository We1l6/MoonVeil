var searchData=
[
  ['loggermanager_74',['LoggerManager',['../classLoggerManager.html',1,'']]],
  ['loggerwindow_75',['LoggerWindow',['../classLoggerWindow.html',1,'']]]
];
