var searchData=
[
  ['loggermanager_76',['LoggerManager',['../classLoggerManager.html',1,'']]],
  ['loggerwindow_77',['LoggerWindow',['../classLoggerWindow.html',1,'']]]
];
