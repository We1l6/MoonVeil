var searchData=
[
  ['imguimanager_73',['ImGuiManager',['../classImGuiManager.html',1,'']]]
];
