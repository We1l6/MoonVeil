var searchData=
[
  ['imguimanager_28',['ImGuiManager',['../classImGuiManager.html',1,'']]]
];
