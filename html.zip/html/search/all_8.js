var searchData=
[
  ['imguimanager_27',['ImGuiManager',['../classImGuiManager.html',1,'']]]
];
